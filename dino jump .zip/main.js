const dino = document.getElementById("dino");
const cactus = document.getElementById("cactus");
const scoreDisplay = document.getElementById("score");

let score = 0;
let isGameOver = false;

cactus.classList.add("cactus-move");

function jump() {
    if (isGameOver) {
        location.reload();
        return;
    }
    if (!dino.classList.contains("animate-jump")) {
        dino.classList.add("animate-jump");
        setTimeout(() => {
            dino.classList.remove("animate-jump");
        }, 500);
    }
}

setInterval(() => {
    if (isGameOver) return;

    let dinoTop = parseInt(window.getComputedStyle(dino).getPropertyValue("top"));
    let cactusLeft = parseInt(window.getComputedStyle(cactus).getPropertyValue("left"));


    if (cactusLeft < 90 && cactusLeft > 50 && dinoTop >= 150) {
        isGameOver = true;
        cactus.style.animation = "none";
        alert("Game Over! Score: " + Math.floor(score));
        location.reload();
    } else {
        score += 0.1;
        scoreDisplay.innerHTML = "Score: " + Math.floor(score);
    }
}, 10);

document.addEventListener("touchstart", jump);
document.addEventListener("mousedown", jump);
document.addEventListener("keydown", (e) => {
    if (e.code === "Space") jump();
});
